use copy_for_ai_core::{Detector, EntityKind, Vault};
use copy_for_ai_ner::{LocalNer, Metrics, ModelVariant, RuntimeConfig, model_directory};
use std::collections::HashSet;

fn main() {
    let models: Vec<_> = [ModelVariant::Fp32, ModelVariant::Int8]
        .into_iter()
        .map(|variant| {
            LocalNer::load_configured(
                &model_directory(),
                RuntimeConfig {
                    variant,
                    token_budget: 256,
                    ..Default::default()
                },
                || false,
                &mut Metrics::default(),
            )
            .unwrap()
        })
        .collect();
    let samples = [
        ("Petr Dvořák pracuje pro Microsoft v Praze.", "Petr Dvořák"),
        ("Alice Morgan works at Microsoft in London.", "Alice Morgan"),
        (
            "Lena Fischer arbeitet bei Microsoft in Berlin.",
            "Lena Fischer",
        ),
        (
            "Claire Dubois travaille chez Microsoft à Paris.",
            "Claire Dubois",
        ),
        (
            "Анна Петрова работает в Microsoft в Москве.",
            "Анна Петрова",
        ),
        ("田中太郎は東京でMicrosoftに勤務しています。", "田中太郎"),
        ("张伟在北京的Microsoft工作。", "张伟"),
        (
            "Meeting with Alice Morgan, Claire Dubois in Paris.\nowner,company,city\nAlice Morgan,Microsoft,Paris\n",
            "Claire Dubois",
        ),
        (
            "Petr Cup Litomyšl\n* setkání zákazníků společnosti Orion Group\n* Vega Systems staví pobočku - informace Tomáš a řeší Adam Horák\nVega a.s.\nEva Veselá\nLitomyšl",
            "Eva Veselá",
        ),
        (
            r#"{"ItemGUID":"abcd1234-1234-1234-1234-abcdef012345","Title":"Meeting with Alice Morgan and Claire Dubois","Cost":329.0,"Date":"2026-10-12","Owner":"Alice Morgan","Vendor":"Microsoft"}"#,
            "Alice Morgan",
        ),
    ];
    let detector = Detector::new();
    let mut total_missing = 0;
    let mut golden_missing = 0;
    for (index, (sample, name)) in samples.into_iter().enumerate() {
        for prefix in [0, 180, 210, 240] {
            let text = format!(
                "{}\n{sample}\n{sample}",
                "The team reviewed the report. ".repeat(prefix)
            );
            let mut results = Vec::new();
            for model in &models {
                let entities = model.detect(&text, || false).unwrap();
                let start = text.find(name).unwrap();
                if !entities
                    .iter()
                    .any(|e| e.kind == EntityKind::Person && e.range == (start..start + name.len()))
                {
                    golden_missing += 1;
                }
                let mut vault = Vault::new();
                let output = vault.process(&detector, &text, &[], &entities).unwrap();
                assert!(
                    vault.restore(&output.text).unwrap().text == text,
                    "round_trip_case={index}"
                );
                results.push(
                    entities
                        .iter()
                        .map(|e| (e.range.start, e.range.end, e.kind))
                        .collect::<HashSet<_>>(),
                );
            }
            let missing = results[0].difference(&results[1]).count();
            total_missing += missing;
            println!(
                "case={index} prefix={prefix} bytes={} fp32={} int8={} missing={missing}",
                text.len(),
                results[0].len(),
                results[1].len()
            );
        }
    }
    println!("cases=40 missing={total_missing} golden_missing={golden_missing}");
}
