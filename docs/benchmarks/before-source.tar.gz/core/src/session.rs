use crate::{EntityKind, Error, MAX_OUTPUT_BYTES, Restored, check_input, marker::MARKER};
use std::collections::HashMap;
use uuid::Uuid;
use zeroize::Zeroize;

struct Mapping {
    kind: EntityKind,
    original: String,
    token: String,
}

impl Drop for Mapping {
    fn drop(&mut self) {
        self.original.zeroize();
    }
}

/// One explicit conversation. All originals remain in this process's memory.
pub struct Session {
    id: Uuid,
    scope: String,
    mappings: Vec<Mapping>,
    counts: HashMap<EntityKind, usize>,
}

impl Default for Session {
    fn default() -> Self {
        Self::new()
    }
}

impl Session {
    pub fn new() -> Self {
        let id = Uuid::new_v4();
        Self {
            id,
            scope: id.simple().to_string()[..8].to_uppercase(),
            mappings: Vec::new(),
            counts: HashMap::new(),
        }
    }

    pub fn id(&self) -> Uuid {
        self.id
    }

    pub(crate) fn original(&self, token: &str) -> Option<&str> {
        self.mappings
            .iter()
            .find(|m| m.token == token)
            .map(|m| m.original.as_str())
    }

    pub(crate) fn contains(&self, kind: EntityKind, value: &str) -> bool {
        self.mappings
            .iter()
            .any(|m| m.kind == kind && m.original == value)
    }

    pub fn scope(&self) -> &str {
        &self.scope
    }

    pub fn len(&self) -> usize {
        self.mappings.len()
    }

    pub fn is_empty(&self) -> bool {
        self.mappings.is_empty()
    }

    pub fn tokens(&self) -> impl Iterator<Item = (EntityKind, &str)> {
        self.mappings.iter().map(|m| (m.kind, m.token.as_str()))
    }

    /// Replaces exact known markers once; restored originals are never rescanned.
    pub fn restore(&self, input: &str) -> Result<Restored, Error> {
        check_input(input)?;
        let mut text = String::with_capacity(input.len());
        let mut cursor = 0;
        let mut replacements = 0;
        let mut unknown_tokens = Vec::new();
        let mut output_length = input.len();
        for matched in MARKER.find_iter(input) {
            if let Some(mapping) = self.mappings.iter().find(|m| m.token == matched.as_str()) {
                output_length = output_length - matched.len() + mapping.original.len();
                if output_length > MAX_OUTPUT_BYTES {
                    return Err(Error::OutputTooLarge);
                }
            }
        }
        for matched in MARKER.find_iter(input) {
            text.push_str(&input[cursor..matched.start()]);
            if let Some(mapping) = self.mappings.iter().find(|m| m.token == matched.as_str()) {
                text.push_str(&mapping.original);
                replacements += 1;
            } else {
                text.push_str(matched.as_str());
                if !unknown_tokens.iter().any(|t| t == matched.as_str()) {
                    unknown_tokens.push(matched.as_str().to_owned());
                }
            }
            cursor = matched.end();
        }
        text.push_str(&input[cursor..]);
        Ok(Restored {
            text,
            replacements,
            unknown_tokens,
        })
    }

    pub(crate) fn token_for(&mut self, kind: EntityKind, original: &str) -> String {
        if let Some(mapping) = self
            .mappings
            .iter()
            .find(|m| m.kind == kind && m.original == original)
        {
            return mapping.token.clone();
        }
        let count = self.counts.entry(kind).or_default();
        *count += 1;
        let token = format!("[[{}_{}_{}]]", kind.tag(), self.scope, count);
        self.mappings.push(Mapping {
            kind,
            original: original.to_owned(),
            token: token.clone(),
        });
        token
    }
}
