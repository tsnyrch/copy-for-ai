use copy_for_ai_core::{Detector, Direction, EntityKind, Vault};
use copy_for_ai_ner::{LocalNer, model_directory};

#[test]
#[ignore = "requires installed 1.16 GB pinned model and ONNX runtime"]
fn real_model_multilingual_round_trip() {
    let model = LocalNer::load(&model_directory()).expect("load verified local model");
    let samples = [
        (
            "cs",
            "Petr Dvořák pracuje pro Microsoft v Praze.",
            "Petr Dvořák",
        ),
        (
            "en",
            "Alice Morgan works at Microsoft in London.",
            "Alice Morgan",
        ),
        (
            "de",
            "Lena Fischer arbeitet bei Microsoft in Berlin.",
            "Lena Fischer",
        ),
        (
            "fr",
            "Claire Dubois travaille chez Microsoft à Paris.",
            "Claire Dubois",
        ),
        (
            "ru",
            "Анна Петрова работает в Microsoft в Москве.",
            "Анна Петрова",
        ),
        (
            "ja",
            "田中太郎は東京でMicrosoftに勤務しています。",
            "田中太郎",
        ),
        ("zh", "张伟在北京的Microsoft工作。", "张伟"),
    ];
    let detector = Detector::new();
    let mut successes = 0;
    for (language, text, person) in samples {
        let entities = model.detect(text, || false).expect("local inference");
        let person_found = entities
            .iter()
            .any(|e| e.kind == EntityKind::Person && &text[e.range.clone()] == person);
        let mut vault = Vault::new();
        let output = vault.process(&detector, text, &[], &entities).unwrap();
        assert_eq!(output.direction, Direction::Anonymize);
        assert_eq!(vault.restore(&output.text).unwrap().text, text);
        eprintln!(
            "language={language}; entities={}; expected_person={person_found}",
            entities.len()
        );
        successes += usize::from(person_found);
    }
    assert!(
        successes == 7,
        "model smoke coverage below required 7/7 synthetic cases"
    );
}

#[test]
#[ignore = "requires installed model"]
fn real_model_detects_after_first_window_and_cancelled_input() {
    let model = LocalNer::load(&model_directory()).unwrap();
    let text = format!(
        "{} Alice Morgan works in London.",
        "Ordinary sentence without personal information. ".repeat(30)
    );
    let entities = model.detect(&text, || false).unwrap();
    let start = text.find("Alice Morgan").unwrap();
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Person && e.range.start == start)
    );
    assert!(matches!(
        model.detect(&text, || true),
        Err(copy_for_ai_ner::Error::Cancelled)
    ));
}

#[test]
#[ignore = "requires installed model"]
fn real_model_processes_generic_business_formats() {
    let model = LocalNer::load(&model_directory()).unwrap();
    let detector = Detector::new();
    let examples = [
        (
            r#"{"ItemGUID":"abcd1234-1234-1234-1234-abcdef012345","Title":"Meeting in Prague","Note":"Eva Veselá meets Petr Dvořák from Microsoft.","Contact":"Eva Veselá","City":"Praha"}"#,
            &["Eva Veselá", "Petr Dvořák"][..],
        ),
        (
            "# Meeting notes\nAlice Morgan from Microsoft meets Claire Dubois in Paris.\nowner,company,city\nAlice Morgan,Microsoft,Paris\n",
            &["Alice Morgan", "Claire Dubois"][..],
        ),
    ];
    for (index, (text, names)) in examples.into_iter().enumerate() {
        let entities = model.detect(text, || false).unwrap();
        let mut vault = Vault::new();
        let output = vault.process(&detector, text, &[], &entities).unwrap();
        for name in names {
            assert!(
                !output.text.contains(name),
                "unmasked person in generic format {index}"
            );
        }
        assert_eq!(vault.restore(&output.text).unwrap().text, text);
        eprintln!("format={index}; replacements={}", output.replacements);
    }
}

#[test]
#[ignore = "requires installed model"]
fn real_model_detects_names_events_and_places_in_short_business_notes() {
    let model = LocalNer::load(&model_directory()).unwrap();
    let text = "Petr Cup Litomyšl\n* setkání zákazníků společnosti Orion Group\n* Vega Systems staví pobočku - informace Tomáš a řeší Adam Horák\nVega a.s.\nEva Veselá\nLitomyšl";
    let entities = model.detect(text, || false).unwrap();
    let output = Vault::new()
        .process(&Detector::new(), text, &[], &entities)
        .unwrap();
    for (index, value) in [
        "Petr Cup Litomyšl",
        "Orion Group",
        "Tomáš",
        "Adam Horák",
        "Eva Veselá",
        "Litomyšl",
    ]
    .iter()
    .enumerate()
    {
        assert!(
            !output.text.contains(value),
            "unmasked business entity {index}"
        );
    }
    eprintln!("business-notes; replacements={}", output.replacements);
}
