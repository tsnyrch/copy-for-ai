use crate::{Error, LABELS};
use gliner::text::{
    splitter::{RegexSplitter, Splitter},
    tokenizer::{HFTokenizer, Tokenizer},
};
use std::ops::Range;

const MAX_CHARACTERS: usize = 640;
const OVERLAP_CHARACTERS: usize = 96;
const MAX_SUBWORDS: usize = 480;

pub(crate) fn next(
    text: &str,
    start: usize,
    splitter: &RegexSplitter,
    tokenizer: &HFTokenizer,
) -> Result<Range<usize>, Error> {
    let tail = &text[start..];
    let mut end = tail
        .char_indices()
        .nth(MAX_CHARACTERS)
        .map_or(text.len(), |(i, _)| start + i);
    loop {
        let chunk = &text[start..end];
        let words = splitter.split(chunk, None).map_err(|_| Error::Inference)?;
        let mut count = 2;
        for label in LABELS {
            count += tokenizer
                .encode("<<ENT>>")
                .map_err(|_| Error::Inference)?
                .len();
            count += tokenizer.encode(label).map_err(|_| Error::Inference)?.len();
        }
        count += tokenizer
            .encode("<<SEP>>")
            .map_err(|_| Error::Inference)?
            .len();
        for word in words {
            count += tokenizer
                .encode(word.text())
                .map_err(|_| Error::Inference)?
                .len();
        }
        if count <= MAX_SUBWORDS {
            return Ok(start..end);
        }
        let chars = chunk.chars().count();
        if chars <= 1 {
            return Err(Error::Inference);
        }
        end = start
            + chunk
                .char_indices()
                .nth(chars / 2)
                .ok_or(Error::Inference)?
                .0;
    }
}

pub(crate) fn overlap_start(text: &str, range: &Range<usize>) -> usize {
    let chunk = &text[range.clone()];
    let keep = OVERLAP_CHARACTERS.min(chunk.chars().count() / 3);
    let offset = chunk.char_indices().rev().nth(keep).map_or(0, |(i, _)| i);
    let start = range.start + offset;
    // Advance through a split word where possible; unspaced scripts still retain overlap.
    text[start..range.end]
        .char_indices()
        .take(24)
        .find(|(_, ch)| ch.is_whitespace())
        .map_or(start, |(i, ch)| start + i + ch.len_utf8())
}
