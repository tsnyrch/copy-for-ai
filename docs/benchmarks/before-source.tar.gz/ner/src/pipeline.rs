use composable::composed;
use gliner::{
    model::{input, output, params::Parameters, pipeline::context::EntityContext},
    text::{splitter::RegexSplitter, tokenizer::HFTokenizer},
};
use orp::pipeline::{Pipeline, PostProcessor, PreProcessor};

pub(crate) struct LocalPipeline {
    pub(crate) splitter: RegexSplitter,
    pub(crate) tokenizer: HFTokenizer,
}

impl LocalPipeline {
    pub(crate) fn new(path: &std::path::Path) -> Result<Self, crate::Error> {
        // Unspaced scripts need smaller units; treating a whole sentence as one word loses entity boundaries.
        let units = r"\p{Han}\p{Hiragana}\p{Katakana}\p{Thai}\p{Lao}\p{Khmer}\p{Myanmar}";
        let word = format!(r"[\w&&[^{units}]]");
        let regex = format!(r"[{units}]\p{{M}}*|{word}+(?:[-_]{word}+)*|\S");
        let splitter = RegexSplitter::new(&regex).map_err(|_| crate::Error::Load)?;
        let tokenizer = HFTokenizer::from_file(path).map_err(|_| crate::Error::Load)?;
        Ok(Self {
            splitter,
            tokenizer,
        })
    }
}

impl<'a> Pipeline<'a> for LocalPipeline {
    type Input = input::text::TextInput;
    type Output = output::decoded::SpanOutput;
    type Context = EntityContext;
    type Parameters = Parameters;

    fn pre_processor(
        &self,
        params: &Parameters,
    ) -> impl PreProcessor<'a, Self::Input, Self::Context> {
        composed![
            input::tokenized::RawToTokenized::new(&self.splitter, params.max_length),
            input::prompt::TokenizedToPrompt::default(),
            input::encoded::PromptsToEncoded::new(&self.tokenizer),
            input::tensors::span::EncodedToTensors::new(params.max_width),
            input::tensors::span::TensorsToSessionInput::default()
        ]
    }

    fn post_processor(
        &self,
        params: &Parameters,
    ) -> impl PostProcessor<'a, Self::Output, Self::Context> {
        composed![
            output::tensors::SessionOutputToTensors::default(),
            output::decoded::span::TensorsToDecoded::new(params.threshold, params.max_width),
            output::decoded::sort::SpanSort::default(),
            output::decoded::greedy::GreedySearch::new(
                params.flat_ner,
                params.dup_label,
                params.multi_label
            )
        ]
    }

    fn expected_inputs(&self, _: &Parameters) -> Option<impl Iterator<Item = &str>> {
        Some(input::tensors::span::SpanTensors::inputs().into_iter())
    }

    fn expected_outputs(&self, _: &Parameters) -> Option<impl Iterator<Item = &str>> {
        Some(output::decoded::span::TensorsToDecoded::outputs().into_iter())
    }
}
