mod assets;
mod chunks;
mod pipeline;

use copy_for_ai_core::{DetectedEntity, EntityKind, MAX_INPUT_BYTES};
use gliner::model::{input::text::TextInput, params::Parameters};
use orp::params::RuntimeParameters;
use std::{
    path::Path,
    time::{Duration, Instant},
};
use thiserror::Error;

pub use assets::model_directory;

const LABELS: &[&str] = &[
    "person",
    "first name",
    "organization",
    "company",
    "location",
    "city",
    "address",
    "event",
];

#[derive(Debug, Error)]
pub enum Error {
    #[error("Chybí lokální vícejazyčný model. Spusťte python3 scripts/install-model.py.")]
    Missing,
    #[error("Soubory modelu neodpovídají ověřené revizi. Instalujte model znovu.")]
    InvalidAssets,
    #[error("Lokální model se nepodařilo načíst. Operace byla zastavena.")]
    Load,
    #[error("Lokální detekce selhala. Operace byla zastavena.")]
    Inference,
    #[error("Operace byla zrušena.")]
    Cancelled,
    #[error("Detekce překročila časový limit. Nic nebylo vloženo.")]
    Timeout,
    #[error("Text překračuje limit 256 KiB.")]
    InputTooLarge,
}

pub struct LocalNer {
    model: orp::model::Model,
    pipeline: pipeline::LocalPipeline,
    parameters: Parameters,
}

impl LocalNer {
    pub fn load(directory: &Path) -> Result<Self, Error> {
        assets::verify(directory)?;
        let tokenizer_path = directory.join("tokenizer.json");
        let model =
            orp::model::Model::new(directory.join("model.onnx"), RuntimeParameters::default())
                .map_err(|_| Error::Load)?;
        let pipeline = pipeline::LocalPipeline::new(&tokenizer_path)?;
        Ok(Self {
            model,
            pipeline,
            parameters: Parameters::default()
                .with_threshold(0.4)
                .with_max_length(None),
        })
    }

    pub fn detect(
        &self,
        text: &str,
        cancelled: impl Fn() -> bool,
    ) -> Result<Vec<DetectedEntity>, Error> {
        if text.len() > MAX_INPUT_BYTES {
            return Err(Error::InputTooLarge);
        }
        let deadline = Instant::now() + Duration::from_secs(90);
        let mut entities = Vec::new();
        let mut start = 0;
        while start < text.len() {
            if cancelled() {
                return Err(Error::Cancelled);
            }
            if Instant::now() >= deadline {
                return Err(Error::Timeout);
            }
            let range = chunks::next(
                text,
                start,
                &self.pipeline.splitter,
                &self.pipeline.tokenizer,
            )?;
            let chunk = &text[range.clone()];
            let input = TextInput::from_str(&[chunk], LABELS).map_err(|_| Error::Inference)?;
            let output = self
                .model
                .inference(input, &self.pipeline, &self.parameters)
                .map_err(|_| Error::Inference)?;
            for span in output.spans.into_iter().flatten() {
                let (from, to) = span.offsets();
                if from >= to || chunk.get(from..to) != Some(span.text()) {
                    return Err(Error::Inference);
                }
                let kind = match span.class() {
                    "person" | "first name" => EntityKind::Person,
                    "organization" | "company" => EntityKind::Organization,
                    "location" | "city" => EntityKind::Location,
                    "address" => EntityKind::Address,
                    "event" => EntityKind::Event,
                    _ => return Err(Error::Inference),
                };
                entities.push(DetectedEntity {
                    range: start + from..start + to,
                    kind,
                });
            }
            if range.end == text.len() {
                break;
            }
            start = chunks::overlap_start(text, &range);
        }
        if cancelled() {
            return Err(Error::Cancelled);
        }
        if Instant::now() >= deadline {
            return Err(Error::Timeout);
        }
        Ok(entities)
    }
}
