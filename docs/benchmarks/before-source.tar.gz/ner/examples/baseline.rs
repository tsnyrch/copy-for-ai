use copy_for_ai_core::{Detector, Vault};
use copy_for_ai_ner::LocalNer;
use std::time::Instant;
fn main() {
 let bytes: usize = std::env::args().nth(1).unwrap().parse().unwrap();
 let paragraph = "Alice Morgan works at Microsoft in London. The team reviewed the report and prepared the next delivery. ";
 let tail = "\nPetr Dvořák pracuje pro Microsoft v Praze.";
 let mut text = paragraph.repeat(bytes / paragraph.len() + 1);
 text.truncate(bytes - tail.len()); text.push_str(tail);
 let start = Instant::now();
 let model = LocalNer::load(&copy_for_ai_ner::model_directory()).unwrap();
 println!("load_ms={}", start.elapsed().as_millis());
 let detector = Detector::new();
 for run in 0..2 {
  let start = Instant::now(); let result = model.detect(&text, || false); let detect = start.elapsed();
  let mut core = 0; let mut restore = 0; let mut count = 0;
  let status = match result {
   Ok(entities) => {
    count = entities.len(); let mut vault=Vault::new(); let start=Instant::now();
    let output=vault.process(&detector, &text, &[], &entities); core=start.elapsed().as_millis();
    match output { Ok(output) => { let start=Instant::now(); let result=vault.restore(&output.text); restore=start.elapsed().as_millis();
     match result { Ok(restored) => { assert!(restored.text == text); "ok" }, Err(_) => "restore_limit" } }, Err(_) => "core_error" }
   }, Err(copy_for_ai_ner::Error::InputTooLarge) => "input_limit", Err(copy_for_ai_ner::Error::Timeout) => "timeout", Err(_) => "model_error"
  };
  println!("run={run} bytes={bytes} status={status} detect_ms={} entities={count} core_ms={core} restore_ms={restore}",detect.as_millis());
 }
}
